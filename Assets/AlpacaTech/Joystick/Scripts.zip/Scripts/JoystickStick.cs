﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

namespace AlpacaTech
{
    public class JoystickStick : MonoBehaviour
    {
        public enum StartArea
        {
            Fill,
            Left,
            Right,
        };

        public enum MoveScope
        {
            Circle,
            Rect
        };

        [Header("Config")]
        [SerializeField] private StartArea startArea = StartArea.Fill;
        [SerializeField] private bool showImageAlways = false;
        public float InputScope = 100.0f;
        [SerializeField] private string AxisX = "";
        [SerializeField] private string AxisY = "";

        [Header("GUI")]
        [SerializeField] private Image imageBase;
        [SerializeField] private Image imageHat;

        [Header("State")]
        public Vector3 Axis = Vector2.zero;
        public bool isPress = false;

        [Header("Workarea")]
        private Vector3 startPosition = Vector3.zero;
        private int fingerId = -999;

        void Awake()
        {
            ShowImage(false);
        }

        private void Start()
        {
            switch (startArea)
            {
                case StartArea.Fill:
                case StartArea.Left:
                    JoystickManager.Instance.sticks[0] = this;
                    break;
                case StartArea.Right:
                    JoystickManager.Instance.sticks[1] = this;
                    break;
            }
        }

        private void ShowImage(bool show)
        {
            if (!showImageAlways)
            {
                imageBase.enabled = show;
                imageHat.enabled = show;
            }
        }
        bool PositionCheck()
        {
            var pos = Input.mousePosition;
            switch (startArea)
            {
                case StartArea.Fill:
                    break;
                case StartArea.Left:
                    if (pos.x > (float)Screen.width / 2)
                    {
                        return false;
                    }
                    break;
                case StartArea.Right:
                    if (pos.x < (float)Screen.width / 2)
                    {
                        return false;
                    }
                    break;
            }
            return true;
        }
        void OnTouchDown(int id)
        {
            if (isPress)
            {
                return;
            }
            if (!PositionCheck())
            {
                return;
            }

            ShowImage(true);
            var pos = Input.mousePosition;
            imageHat.transform.position = pos;
            imageBase.transform.position = pos;
            isPress = true;
            Axis = Vector3.zero;
            startPosition = pos;
            fingerId = id;
        }

        void OnTouchPress(int id, Vector3 pos)
        {
            if (fingerId != id)
            {
                return;
            }
#if true
            //  Circle
            var delta = pos - startPosition;
            var len = delta.magnitude;
            len = Mathf.Min(len, InputScope);
            delta = delta.normalized * len;
            imageHat.transform.position = startPosition + delta;
            Axis = delta / InputScope;
#else
            //  Rect
            pos.x = Mathf.Clamp(pos.x, startPosition.x - inputScope, startPosition.x + inputScope);
            pos.y = Mathf.Clamp(pos.y, startPosition.y - inputScope, startPosition.y + inputScope);

            imageHat.transform.position = pos;
            Axis.x = (pos.x - startPosition.x)/inputScope;
            Axis.y = (pos.y - startPosition.y)/inputScope;
#endif
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="pos"></param>
        void OnTouchUp(int id, Vector3 pos)
        {
            if (fingerId != id)
            {
                return;
            }

            isPress = false;
            Axis = Vector3.zero;
            imageHat.transform.position = startPosition;
            ShowImage(false);
        }

        /// <summary>
        /// 
        /// </summary>
        void Update()
        {
            var touches = Input.touches;

            //  Key
            try
            {
                var ix = Input.GetAxis(AxisX);
                var iy = Input.GetAxis(AxisY);
                Axis.x = ix;
                Axis.y = iy;
            }
            catch
            {

            }

            if (!isPress)
            {
#if UNITY_EDITOR
                if (EventSystem.current.IsPointerOverGameObject())
                {
                    return;
                }
#endif
                foreach (var touch in Input.touches)
                {
                    if (EventSystem.current.IsPointerOverGameObject(touch.fingerId))
                    {
                        return;
                    }
                }
            }

#if (UNITY_IOS || UNITY_ANDROID)
            //  Touch
            foreach (var touch in touches)
            {
                switch (touch.phase)
                {
                    case TouchPhase.Began:
                        OnTouchDown(touch.fingerId);
                        break;
                    case TouchPhase.Stationary:
                    case TouchPhase.Moved:
                        OnTouchPress(touch.fingerId, touch.position);
                        break;
                    case TouchPhase.Ended:
                    case TouchPhase.Canceled:
                        OnTouchUp(touch.fingerId, touch.position);
                        break;
                }
            }
#endif

#if UNITY_EDITOR
            //  Mouse
            if (Input.GetMouseButtonDown(0))
            {
                OnTouchDown(-1);
            }
            if (Input.GetMouseButton(0))
            {
                OnTouchPress(-1, Input.mousePosition);
            }
            if (Input.GetMouseButtonUp(0))
            {
                OnTouchUp(-1, Input.mousePosition);
            }
#endif
        }
    }
}