﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace AlpacaTech
{
    public class JoystickButton : MonoBehaviour
    {
        public int ID = 0;
        [SerializeField] private string buttonName = "";

        float pressTime = 0;
        int pressCount = 0;
        bool press = false;
        bool pressBack = false;

        private void Awake()
        {
            var pointerDown = new EventTrigger.Entry();
            pointerDown.eventID = EventTriggerType.PointerDown;
            pointerDown.callback.AddListener((data) => { OnDown(); });

            var pointerUp = new EventTrigger.Entry();
            pointerUp.eventID = EventTriggerType.PointerUp;
            pointerUp.callback.AddListener((data) => { OnUp(); });

            var triggers = GetComponent<EventTrigger>().triggers;
            triggers.Add(pointerDown);
            triggers.Add(pointerUp);
        }

        private void Start()
        {
            JoystickManager.Instance.buttons[ID] = this;
        }

        public void OnDown()
        {
            press = true;
            pressCount = 1;
            pressTime = 0;
        }

        private void OnUp()
        {
            press = false;
            pressCount = 0;
            pressTime = 0;
        }

        void Update()
        {
            pressBack = press;
//            Debug.Log("button " + ID.ToString() + " " + state.ToString());
            if (press)
            {
                pressTime += Time.unscaledDeltaTime;
            }

            if (buttonName.Length != 0)
            {
                try
                {
                    press = Input.GetButton(buttonName);
                }
                catch
                {

                }
            }
        }

        public bool GetDown()
        {
            return press && !pressBack;
        }

        public bool GetUp()
        {
            return !press && pressBack;
        }

        public bool GetPress()
        {
            return press;
        }

    }
}