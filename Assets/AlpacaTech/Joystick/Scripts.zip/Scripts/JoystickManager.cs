﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AlpacaTech
{
    /// <summary>
    /// 
    /// AxisのDown/Press/Up
    /// ButtonのDown/Press/Up
    /// ButtonのRepeat
    /// 
    /// </summary>
    public class JoystickManager
    {
        public enum StickType
        {
            Left,
            Right,
        };

        public static JoystickManager Instance = new JoystickManager();
        public JoystickStick[] sticks = new JoystickStick[2];
        public JoystickButton[] buttons = new JoystickButton[8];

        public static Vector2 GetAxis(StickType stickType)
        {
            return GetAxis((int)stickType);
        }
        public static Vector2 GetAxis(int stickId)
        {
            return Instance.sticks[stickId].Axis;
        }

        public static bool GetButtonDown(int id)
        {
            return Instance.buttons[id].GetDown();
        }

        public static bool GetButtonUp(int id)
        {
            return Instance.buttons[id].GetUp();
        }

        public static bool GetButton(int id)
        {
            return Instance.buttons[id].GetPress();
        }

        public static bool GetButtonRepat(int id)
        {
            return false;
        }
    }
}